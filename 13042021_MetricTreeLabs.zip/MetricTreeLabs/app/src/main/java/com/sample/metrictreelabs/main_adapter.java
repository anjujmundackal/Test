package com.sample.metrictreelabs;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.sample.metrictreelabs.model.BreakingCharacters;

import java.util.ArrayList;

public class main_adapter extends RecyclerView.Adapter<main_adapter.MainCategoryViewHold> {

    ArrayList<BreakingCharacters> characterlist;
    int selecteditem = 0;
    Context context;


    public main_adapter(ArrayList<BreakingCharacters> characterlist, Context context) {
        this.characterlist = characterlist;
        this.context = context;

    }

    @NonNull

    @Override
    public main_adapter.MainCategoryViewHold onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.characterlist, parent, false);

        return new main_adapter.MainCategoryViewHold(view);

    }

    @Override
    public void onBindViewHolder(@NonNull main_adapter.MainCategoryViewHold holder, int position) {


        BreakingCharacters characters = characterlist.get(position);

        Glide.with(context)
                .load(characters.getImg())
                .fitCenter()
                .into(holder.image);
        holder.name.setText(characters.getName());




    }

    public int getItemCount() {
        return characterlist.size();

    }



    public class MainCategoryViewHold extends RecyclerView.ViewHolder {


        ImageView image;
        TextView name;




        public MainCategoryViewHold(@NonNull View itemView) {
            super(itemView);
            image = itemView.findViewById(R.id.image);
            name = itemView.findViewById(R.id.cname);


        }
    }
}