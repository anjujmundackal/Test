package com.sample.metrictreelabs;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.widget.SearchView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;
import com.sample.metrictreelabs.model.BreakingCharacters;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class SearchResultActivity extends AppCompatActivity {

    Bundle bundle;
    String searchtext;

    SearchView searchbar;
    RequestQueue mQueue;
    ProgressDialog progressDialog ;
    ArrayList<BreakingCharacters> characterlist= new ArrayList<>();;
    String name, img;
    RecyclerView bbcharacter;
    RecyclerView.Adapter main_character_adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_result);

        bundle=getIntent().getExtras();
        searchtext=bundle.getString("searchtext");

        bbcharacter = findViewById(R.id.characterlist);
        searchbar=findViewById(R.id.searchbar);


        bbcharacter.setHasFixedSize(true);
        bbcharacter.setLayoutManager(new GridLayoutManager(getApplicationContext(), 1));

        searchlist();
       // Toast.makeText(this, ""+searchtext, Toast.LENGTH_SHORT).show();
    }

    private void searchlist() {

        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Loading..");
        progressDialog.show();

        // Toast.makeText(SearchActivity.this, "Response", Toast.LENGTH_SHORT).show();
        String characters="https://www.breakingbadapi.com/api/characters?name="+searchtext;
        mQueue= Volley.newRequestQueue(this);

        JsonArrayRequest request=new JsonArrayRequest(Request.Method.GET, characters, null, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                //Toast.makeText(SearchActivity.this, "Response"+response, Toast.LENGTH_SHORT).show();


                try{
                    characterlist=new ArrayList<>();
                    for(int i=0;i<response.length();i++){
                        // Get current json object
                        JSONObject BBCharacters = response.getJSONObject(i);



                        name=BBCharacters.getString("name");
                        img=BBCharacters.getString("img");

                        characterlist.add(new BreakingCharacters(name,img));


                          // Toast.makeText(SearchResultActivity.this, ""+name+ ""+img, Toast.LENGTH_SHORT).show();
                    }

                    main_character_adapter = new main_adapter(characterlist, getApplicationContext());
                    bbcharacter.setAdapter(main_character_adapter);
                    progressDialog.dismiss();

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }

        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
                progressDialog.dismiss();

            }
        });
        mQueue.add(request);

    }
}