package com.sample.metrictreelabs;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.SearchView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.sample.metrictreelabs.model.BreakingCharacters;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class SearchActivity extends AppCompatActivity {

    SearchView searchbar;
    RequestQueue mQueue;
    ProgressDialog progressDialog ;
    ArrayList<BreakingCharacters> characterlist= new ArrayList<>();;
    String name, img;
    RecyclerView bbcharacter;
    RecyclerView.Adapter main_character_adapter;
    Context context;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);

        bbcharacter = findViewById(R.id.characterlist);
        searchbar=findViewById(R.id.searchbar);


        bbcharacter.setHasFixedSize(true);
        bbcharacter.setLayoutManager(new GridLayoutManager(this, 1));
        searchfunction();
        characterlist();

    }

    private void characterlist() {

        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Loading..");
        progressDialog.show();

       // Toast.makeText(SearchActivity.this, "Response", Toast.LENGTH_SHORT).show();
        String characters="https://www.breakingbadapi.com/api/characters";
        mQueue= Volley.newRequestQueue(this);

        JsonArrayRequest request=new JsonArrayRequest(Request.Method.GET, characters, null, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {


                    try{

                        for(int i=0;i<response.length();i++){

                            JSONObject BBCharacters = response.getJSONObject(i);



                        name=BBCharacters.getString("name");
                        img=BBCharacters.getString("img");

                        characterlist.add(new BreakingCharacters(name,img));


                     //   Toast.makeText(SearchActivity.this, ""+name+ ""+img, Toast.LENGTH_SHORT).show();
                    }

                    main_character_adapter = new main_adapter(characterlist, getApplicationContext());
                    bbcharacter.setAdapter(main_character_adapter);
                    progressDialog.dismiss();

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }

        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
                progressDialog.dismiss();

            }
        });
        mQueue.add(request);

    }

    private void searchfunction() {
        searchbar.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {


              //   Toast.makeText(getApplicationContext(), ""+query,Toast.LENGTH_LONG).show();

                Intent i = new Intent(SearchActivity.this, SearchResultActivity.class);
                i.putExtra("searchtext",query);
                startActivity(i);
                searchbar.setQuery("",false);


                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                return false;
            }
        });
    }
}